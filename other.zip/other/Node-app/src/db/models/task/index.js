// для работы с базой данных подключаю mongoose
const mongoose = require("mongoose");

//со всеми таблицами работаю через смехы, 
//поэтому из mongoose вытаскиваем элемент schema 
const { Schema } = mongoose;
//создаю свою схему
const taskScheme = new Schema({
  //обязательно задаем тип данных
  text: String,
  isCheck: Boolean
});
//создаю модель для работы с таблицей в самой базе данных 
//(модель таблицы tasks которая будет хронить все таски по схеме taskScheme)
// + экспорт нашей модели
module.exports = Task = mongoose.model("tasks", taskScheme);
