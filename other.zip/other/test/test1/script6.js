// Написать функцию, которая параметром принимает массив. 
// Вывести четные значения массива.

const array3 = [3, 5, 6, 8, 6, 3];

const testFunction5 = (arr) => {
  const result = [];

  arr.forEach(value => {
    if (value % 2 === 0) {
      return console.log(value);
    }
  });
}

const result4 = testFunction5(array3); 