// Написать функцию, которая параметром принимает массив. 
// Вывести четные значения массива.

const array3 = [3, 5, 6, 8, 6, 3];

const testFunction7 = (el, arr) => {
  const newArr = [];
  const result = -1;

  arr.forEach((element, index) => {
    if (element === el) {
      newArr.push(index);
    }

  });
  console.log(newArr);
}

const result7 = testFunction7(3, array3); 