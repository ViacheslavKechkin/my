// Написать функцию, которая параметром принимает массив элементов и значение. 
// Функция возвращает true,если в массиве есть это значение, иначе false.


const array = [4, 6, 2, 7, 8, 5];

const testFunction14 = (arr, val1) => {
  let result = false;

  arr.forEach(value => {
    if (value === val1) {
      result = true;
    } 
    return console.log(result);
  });
}

const result12 = testFunction14(array, 4);