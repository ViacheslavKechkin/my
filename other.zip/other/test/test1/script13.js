// Написать функцию, которая параметром принимает массив. 
// Функция возвращает true, если все значения положительные, иначе false.


const array = [3, 5, 6, 8, 6, 3];

const testFunction13 = (arr) => {

  let result = false;

  arr.forEach(value => {
    if (value < 0) {
      result = false;;
      return console.log(result);
    } else {
      result = true;
      //return console.log(result);
    }
  });
  return console.log(result);
  

  
}

const result13 = testFunction13(array); 