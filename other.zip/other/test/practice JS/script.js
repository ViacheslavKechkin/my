// 1/34
// Отфильтровать коллекцию по конкретному условию
// Отфильтровать значения, где age > 20

const elements = [
  { name: 'test', age: 45, country: 'RF', tel: '+79846466744' },
  { name: 'test1', age: 23, country: 'RF', tel: '+79464747484' },
  { name: 'test2', age: 18, country: 'RF', tel: '+376483876346' }
];

const filterEl = (arr) => {
  let mawAge = 20;

  const result = [];

  arr.forEach(value => {
    if (value.age > mawAge) {
      result.push(value);
    }
  });

  return console.log("taskJS_1/34-", result);
}

const filterArray = filterEl(elements);

// 2/34
// Добавить в первый массив только те значения, 
// которые присутствуют во втором, но нет в первом
//     Выводит [5, 8, -3, 7, 3, 7, 3, 8, 9, 2, 8, -2, 6, 1, 4]
let array1 = [5, 8, -3, 7, 3, 7, 3, 8, 9, 2, 8, -2];
const array2 = [8, 5, 7, -3, 6, 3, 1, 4, 2];

const mergeArray = (arr1, arr2) => {

  arr2.forEach((el2) => {
    let flag = true;

    arr1.forEach(el1 => {
      if (el2 === el1) {
        return flag = false;
      }
    });

    if (flag) {
      arr1.push(el2);
    }

  });
  console.log("taskJS_2/34-", array1);


}

const mergeArr = mergeArray(array1, array2);



// // 3/34
// Дана строка, например, '123456'. 
// Переверните эту строку (сделайте из нее '654321')
// Input:
// '67927647'

const reversStr = (str) => {
  let Str3 = "";
  for (let i = str.length - 1; i >= 0; i--) {
    Str3 += str[i];
  }
  return console.log("taskJS_3/34-", Str3);
}
const result3 = reversStr('67927647');

// 4/34
//Удалите в строке все символы "!"
// Input:
// 'test! education! part!!! 2!!!!'
// Output:
// 'test education part 2'

const newStr = 'test! education! part!!! 2!!!!';
const newArr4 = [];
let Str4 = '';

const deleteSign = (str) => {
  const newArr = str.split(' ');

  newArr.forEach(el => {
    if (el.endsWith('!')) {
      newArr4.push(el.replaceAll('!', ''));
    }
  });

  Str4 = newArr4.join(' ');

  console.log("taskJS_4/34-", newArr4);
  return console.log("taskJS_4/34-", Str4);
}

const result4 = deleteSign(newStr);

// // 5/34
// Дано число, например 31. 
// Проверьте, что это число не делится ни на одно другое число 
// кроме себя самого и единицы. То есть в нашем случае нужно проверить, 
// что число 31 не делится на все числа от 2 до 30. 
// Если число не делится - выведите 'false', а если делится - выведите 'true'.

const countFunction = (number) => {

  let flag = '';

  if (number === 1) {
    flag = false;
    return console.log("taskJS_5/34-1-false", flag);
  } else {
    for (let i = 2; i < number; i++) {
      if (number % i === 0) {
        flag = true;
        return console.log("taskJS_5/34-true", flag);

      } else {
        flag = false;
        return console.log("taskJS_5/34-false", flag);
      }
    };
    // flag = true;
    // return console.log("taskJS_5/34-", flag);
  }


}
const result5 = countFunction(31);


// 6/34
// Вернуть массив уникальных примитивов
// На вход подается массив со значениями.
// Нужно вывести массив уникальных элементов (нет повторений в поданном массиве):
// Input:
// [5, 7, 6, 2, 8, 3, 5, 6, 2, 98, 13]
// Output:
// [7, 8, 3, 98, 13]

const arr6 = [5, 7, 6, 2, 8, 3, 5, 6, 2, 98, 13];
const arr6Copy = [...arr6];
const resultArr6 = [];
let count6 = 0;

const countFunction6 = (arr) => {

  arr.forEach(el1 => {
    count6 = 0;

    arr6Copy.forEach(el2 => {
      if (el1 === el2) {
        ++count6;
      }
    });

    if (!(count6 > 1)) {
      resultArr6.push(el1);
    }
  });

  console.log("taskJS_6/34-", resultArr6);
}

const result6 = countFunction6(arr6);


// 7/34
// Дана строка. Показать третий, шестой, девятый и так далее символы
// Input:
// 'text education part 2'

const text = 'text education part 2';

const countFunction7 = (str) => {

  for (let i = 3; i < str.length; i++) {
    if (i % 3 === 0) {
      console.log("taskJS_7/34-", str.charAt(i));
    }
  }
}

const result7 = countFunction7(text);

// 8/34
// Убрать из массива все "отрицательные" значения 
// и вернуть только массив из "положительных"
// Input:
// // [6, 4, 8, -2, 6, 8, -1, 7, 8, 8, -9, 3, 5]
// Output:
// [6, 4, 8, 6, 8, 7, 8, 8, 3, 5]

const arr8 = [6, 4, 8, -2, 6, 8, -1, 7, 8, 8, -9, 3, 5];

const newArr8 = [];

const testFunction8 = (arr) => {

  arr.forEach(el => {
    if (el >= 0) {
      newArr8.push(el);
    }
  });
  return console.log("taskJS_8/34-", newArr8);
}

const result = testFunction8(arr8);

// 9/34
// Дан двухмерный массив с числами, например [[1, 2, 3], [4, 5], [6]]. 
// Найдите сумму элементов этого массива. 
// Массив, конечно же, может быть произвольным

const arr9 = [[1, 2, 3], [4, 5], [6]];

const result9 = 0;

const addFunction9 = (arr, result) => {
  arr.forEach(el => {
    el.forEach(el2 => {
      result += el2;
    });
  });

  return console.log("taskJS_9/34-", result);
}

const addFun = addFunction9(arr9, result9);

// 11/34
// Дан массив чисел. Каждое число в массиве встречается четное количество раз, 
// кроме одного. Реализуйте и экспортируйте функцию по умолчанию, 
// которая принимает массив чисел и возвращает число, 
// которое встречается нечетное количество раз
// Input:
// [5, 8, 2, 4, 5, 4, 2, 4, 2, 5, 2, 4, 5]
// Output:
// 8

const arr11 = [5, 8, 2, 4, 5, 4, 2, 4, 2, 5, 2, 4, 5];
//const arr11 = [5, 8, 2, 4, 5, 4, 2, 4, 2, 5, 2, 4, 5];
const arr11Copy = [...arr11];

const countFunction11 = (arr) => {
  let resultNumber11 = 0;
  let count11 = 0;

  arr.forEach(el1 => {
    count11 = 0;
    arr11Copy.forEach(el2 => {
      if (el1 === el2) {
        ++count11;
      }
    });
    if (!(count11 % 2 === 0)) {
      resultNumber11 = el1;
    }

  });

  console.log("taskJS_11/34-", resultNumber11);
  // return newArr6;
}
const result11 = countFunction11(arr11);

// 12/34
// Отфильтровать коллекцию, где у объекта есть свойство с конкретным значением
// Отфильтровать значения, где age равен 23
// Output:
// [
//    {name: 'test1', age: 23, country: 'RF', tel: '+79464747484'}
// ]
const collection12 = [
  { name: 'test', age: 45, country: 'RF', tel: '+79846466744' },
  { name: 'test1', age: 23, country: 'RF', tel: '+79464747484' },
  { name: 'test2', age: 18, country: 'RF', tel: '+376483876346' }
];


const countFunction12 = (arr, el1) => {
  let newArr12 = [];

  arr.forEach(value => {
    if (value.age === el1) {
      newArr12.push(value);
    }
  });
  return console.log("taskJS_12/34-", newArr12);
}

const result12 = countFunction12(collection12, 23);

// 13/34
// Вернуть самый длинный элемент (строку) в массиве
// Input:
//  ['test', 'education', 'example', 'exceed', 'team', 'exceed.team', 'rest', 'response']
// Output:
// 'exceed.team'

const arr13 = ['test', 'education', 'example', 'exceed', 'team', 'exceed.team', 'rest', 'response'];

const getLengthFunction13 = (arr) => {
  let maxLength = 0;
  let idx13 = -1;
  let longestEl = '';

  arr.forEach((el, index) => {
    if (el.length > maxLength) {
      maxLength = el.length;
      idx13 = index;
      longestEl = arr13[idx13]
    }
  });

  return console.log("taskJS_13/34-", longestEl);
}

const result13 = getLengthFunction13(arr13);

// 14/34
//Сгруппировать объекты заказов по имени
// Input:
// [
//    {name: 'test', price: 200},
//    {name: 'test1', price: 300},
//    {name: 'test', price: 100},
//    {name: 'test', price: 600}
// ]
// Output:
// [
//    {name: 'test', price: 900},
//    {name: 'test1', price: 300}
// ]

const arr14 = [
  { name: 'test', price: 200 },
  { name: 'test1', price: 300 },
  { name: 'test', price: 100 },
  { name: 'test', price: 600 }
];

const newArr14 = [
  { name: 'test', price: 0 },
  { name: 'test1', price: 0 },

];

const grupFunc14 = (arr1, arr2) => {

  arr1.forEach(el1 => {
    if (el1.name === 'test') {
      arr2.forEach(el2 => {
        if (el2.name === 'test') {
          el2.price += el1.price;
        }
      });
    } else (
      arr2.forEach(el2 => {
        if (el2.name === 'test1') {
          el2.price += el1.price;
        }
      })
    )
  });

  return console.log("taskJS_14/34-", newArr14);
}

const result14 = grupFunc14(arr14, newArr14);

// 15/34
// Дано число. Сложите его цифры. Если сумма получилась более 9-ти, 
// опять сложите его цифры. И так, пока сумма не станет однозначным числом (9 и менее)
// Input:
// 345
// Output:
// 3

const countFunction15 = (numb) => {
  let number15 = '' + numb;
  let sum15 = 0;
  let sum15Two = 0;

  for (let i = 0; i < number15.length; i++) {
    sum15 += +number15[i];
  }

  if (sum15 > 9) {
    let newNumber15 = '' + sum15;

    for (let i = 0; i < newNumber15.length; i++) {
      sum15Two += +newNumber15[i];
    }
  } else {
    console.log("taskJS_15/34-", sum15);
  }

  console.log("taskJS_15/34-", sum15Two);

  // let arr = String(number15).split('');
  // for (let i = 0; i < arr.length; i++) {
  //   sum += parseInt(arr[i]);
  //   console.log(sum);
  // }

}
const result15 = countFunction15(345);

// 16/34
// Напишите программу, создающую строку, содержащую решётку 8х8, 
// в которой линии разделяются символами новой строки. 
// На каждой позиции либо пробел, либо #. 
//В результате должна получиться шахматная доска.

const size = 8;

let board = "";

for (let y = 0; y < size; y++) {
  for (let x = 0; x < size; x++) {
    if ((x + y) % 2 == 0)
      board += " ";
    else
      board += "#";
  }
  board += "\n";
}

console.log(board);

//const result16 = testFunction16();

// 17/34
// Реализуйте функцию, которая параметром принимает объект. 
// Выведите сформированную строку для браузера ('https://underscorejs.org') с параметрами. 
// Например, {a: 4, b:8} => 'https://underscorejs.org?a=4&b=8'

// ('https://docs.google.com', {id: 'terdh673bb8', limit: 5, offset: 0})
// Output:
// 'https://docs.google.com?id=terdh673bb8&limit=5&offset=0'


const data17 = {
  id: 'terdh673bb8',
  a: 5,
  b: 0
};

let site17 = 'https://docs.google.com';

const testFunction17 = (obj) => {
  //const {id, a, b} = {id: 'terdh673bb8', a: 4, b: 8};

  let newSite17 = `${site17}?id=${obj.id}&limit=${obj.a}&offset=${obj.b}`;

  console.log("taskJS_17/34-", newSite17);
}


const result17 = testFunction17(data17);


// 18/34
// Удалить из первого массива все значения, которые указаны во втором массиве
// Input:
// ([5, 7, 2, -1, 7, 8, 3, 6, 2, 9, 4, -7], [2, -1, 9])
// Output:
// [5, 7, 7, 8, 3, 6, 4, -7]


let arrDel11 = [5, 7, 2, -1, 7, 8, 3, 6, 2, 9, 4, -7];
const arrDel12 = [2, -1, 9];

const delFunction18 = (arr1, arr2) => {
  let idx = -1;
  let flag = false;

  arr2.forEach((el2) => {

    arr1.forEach((el1, index) => {
      flag = false;
      if (el2 === el1) {
        idx = index;
        flag = true;
        console.log("flag", flag);

      } if (flag) {
        arrDel11.splice(idx, 1);
      }
    });

  });
  console.log("taskJS_18/34-", arrDel11);
}

const delArr18 = delFunction18(arrDel11, arrDel12);

// 19/34
// Заменить в строке все точки на '[.]'
// Input:
// '.test.education.part.2.'
// Output:
// '[.]test[.]education[.]part[.]2[.]'

const text19 = '.test.education.part.2.';
const newText = text19.replaceAll('.', '[.]');

console.log("taskJS_19/34-", newText);

// 20/34
// Напишите код, который находит наиболее часто встречаемый элемент массива.
// Input:
// [6, 3, 8, 2, 6, 8, 2, 5, 7, 2, 6, 8, 6, 2, 6]
// Output:
// 6

const arr20 = [6, 3, 8, 2, 6, 8, 2, 5, 7, 2, 6, 8, 6, 2, 6];

const testFunction20 = (arr) => {

  let count20 = 0;
  let maxItem20 = 0;
  let idx = -1;

  arr.forEach((el1, index) => {

    if (count20 > maxItem20) {
      maxItem20 = count20;
      console.log("taskJS_20/34-", arr20[idx]);
    }

    count20 = 0;
    idx = index;

    arr.forEach(el2 => {
      if (el1 === el2) {
        ++count20;
      }
    });
  });

}

const result20 = testFunction20(arr20);

// 21/34
// Дана строка вида 'var_text_hello'. Сделайте из него текст 'varTextHello'
// Input:
// 'text_education_part_2'
// Output:
// 'textEducationPart2'

const text21 = 'text_education_part_2';
const Arr21 = text21.split('_');
const newArr21 = [];

console.log("taskJS_21/34-", newArr21);

const testFunction21 = (arr) => {

  arr.forEach((value, index) => {
    if (index === 0) {
      newArr21.push(value);
    } else {
      value = value.charAt(0).toUpperCase() + value.slice(1);
      newArr21.push(value);
    }
  });

  const finishArr = newArr21.join('');
  console.log("taskJS_21/34-", finishArr);

}
const result21 = testFunction21(Arr21);

// 22/34
// Отфильтровать массив чисел по максимальному и минимальному числам
// Нужно реализовать функцию, которая в параметрах всегда получает массив. 
// И на выбор следующие параметры:
// 1) только минимальный элемент
// 2) только максимальный элемент
// 3) и минимальный, и максимальный элемент
// Если пользователю приходит только минимальный, то нужно вывести все значения, 
// которые от минимального и выше.
// Если пользователю приходит только максимальный элемент, 
// то нужно вывести все значения до максимального.
// Если приходят оба значения вывести все значения от минимального и до максимального элемента.
// Input:
// ([-4, 6, 7, 2, -5, 8], 3, null)
// Output:
// [6, 7, 8]
// Input:
// ([-4, 6, 7, 2, -5, 8], null, 6)
// Output:
// [-4, 6, 2, -5]
// Input:
// ([-4, 6, 7, 2, -5, 8], -1, 5)
// Output:
// [2]

const arr22 = [-4, 6, 7, 2, -5, 8];
const maxArr = [];
const minArr = [];
let newArrSort = [];


const testFunction22 = (arr, minNumb, maxNumb) => {
  let max = 0;
  let min = 0;
  // бабл сортировка (получил отсортированный массив)
  const bubbleSort = (arr) => {
    for (let i = 0, endI = arr.length - 1; i < endI; i++) {
      let flagSwap = false;
      for (let j = 0, endJ = endI - i; j < endJ; j++) {
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          flagSwap = true;
        }
      }
      if (!flagSwap) break;
    }
    return arr;
  };

  bubbleSort(arr);
  //получил отсортированный массив по возрастанию 
  console.log("taskJS_22/34-arr sort", arr22);

  let arrMin = [];
  let arrMax = [];
  let averageValue = [];
  let newArrLastSort = [...arr];
  // ([-4, 6, 7, 2, -5, 8], -1, 5)
  // sort [-5, -4, 2, 6, 7, 8]
  if (minNumb !== null && maxNumb !== null) {
    arr.forEach(value => {
      if ((value > minNumb) && (value < maxNumb)) {
        averageValue.push(value);
      }
    });
  }

  if (maxNumb === null) {
    arr.forEach(value => {
      if (value >= minNumb) {
        averageValue.push(value);
      }
    });
  }

  if (minNumb === null) {
    arr.forEach(value => {
      if (value <= maxNumb) {
        averageValue.push(value);
      }
    });
  }
  console.log("taskJS_22/34-", averageValue);

}

const result22 = testFunction22(arr22, null, 6);


// 23/34
// Напишите функцию, параметром которой является строка. 
// Напишите код, создающий массив, который будет состоять из первых букв слов
// Input:
// 'test education part 2'
// Output:
// ['t', 'e', 'p', '2']

const text22 = 'test education part 2';

const newArr22 = [];

const testFunction23 = (str) => {

  const Arr22 = str.split(' ');
  console.log("taskJS_23/34-", Arr22);

  Arr22.forEach((value) => {
    if (value) {
      newArr22.push(value.charAt(0));
    }
  });
  console.log("taskJS_23/34-", newArr22);
}
const result23 = testFunction23(text22);

// 24/34
// Вернуть true, если в массиве есть все значения, которые указаны во втором
// Input:
// ([4, 8, 1, 9, -3, 7, 2, 8, 4, -6, 3, 8, 4, 6, 1, 9, -4], [3, 7, -6])
// Output:
// true
// Input:
// ([4, 8, 1, 9, -3, 7, 2, 8, 4, -6, 3, 8, 4, 6, 1, 9, -4], [9, 7, -8])
// Output:
// false

const arr24one = [4, 8, 1, 9, -3, 7, 2, 8, 4, -6, 3, 8, 4, 6, 1, 9, -4];
const arr24two = [3, 7, -6];

const countArr24 = arr24two.length;

let countHit = 0;
let answerTrueOrFalse = '';

const testFunction24 = (arr1, arr2) => {

  let flag24 = false;

  arr2.forEach(value2 => {

    flag24 = false;
    arr1.forEach(value1 => {
      if (!flag24) {
        if (value2 === value1) {
          flag24 = true;
          ++countHit;
          return;
        }
      }
    });

  });

  if (countHit === countArr24) {
    answerTrueOrFalse = true;
  } else {
    answerTrueOrFalse = false;
  }

  console.log("taskJS_24/34-", countHit);
  console.log("taskJS_24/34-", answerTrueOrFalse);
}

const result24 = testFunction24(arr24one, arr24two);


// 25/34 верстка


// 26/34
// В данной строке найти количество цифр.
// Input:
// 'sdj473mn274bc82'
// Output:
// 8
const text26 = 'sdj473mn274bc82';

const newArr26 = text26.split('');
console.log("taskJS_26/34-", newArr26);

let count26 = 0;

const countDigits = (arr) => {
  arr.forEach(value => {
    if (Number(value)) {
      if ((typeof +value) === "number") {
        ++count26;
      }
    }

  });
  console.log("taskJS_26/34-", count26);
}

const result26 = countDigits(newArr26);

// 27/34
// Дан массив строк. Упорядочить массив по длине строк
// Input:
// ['test', 'education', 'part', '2', 'exceed.team']
// Output:
// ['2', 'part', 'test', 'education', 'exceed.team']

const newArr27 = ['test', 'education', 'part', '2', 'exceed.team'];
let maxEl = 0;

const testFunction27 = (arr) => {
  const newArr27 = [];

  arr.forEach(value => {
    if (value.length > maxEl) {
      maxEl = value.length;

      newArr27.push(value);
    } else {
      newArr27.unshift(value);
    }
  });

  console.log("taskJS_27/34-", newArr27);
}

const result27 = testFunction27(newArr27);

// 28/34
// Строка состоит из слов, разделенных одним или несколькими пробелами. 
// Переставьте слова по убыванию их длин.
// Input:
// 'test education part 2'
// Output:
// 'education part test 2'

const newStr28 = 'test education part 2';
const newStrNew28 = newStr28.replaceAll('  ', ' ');
const newArr28 = newStrNew28.split(' ');


const testFunction28 = (arr) => {
  let maxEl28 = 0;
  let newArray28 = [];

  arr.forEach(value => {
    if (value.length > maxEl28) {
      maxEl28 = value.length;
      newArray28.unshift(value);
    } else {
      newArray28.push(value);
    }

  });

  newArray28.join(' ');

  console.log("taskJS_28/34-", newArr28);
  console.log("taskJS_28/34-", newArray28.join(' '));
}

const result28 = testFunction28(newArr28);


// 29/34
// Создайте объект с днями недели. 
// Ключами в нем должны служить номера дней от начала недели (понедельник - первый и т.д.). 
// Передать в функцию день месяца от 1-31. Выведите на экран текущий день недели. 
// Учитываем, что 1-е число понедельник.
// {
//   1: 'Понедельник',
//   2: 'Вторник',
//   3: 'Среда',
//   4: 'Четверг',
//   5: 'Пятница',
//   6: 'Суббота',
//   7: 'Воскресенье'
// }
// Input:
// func(25);
// Output:
// 'Четверг'
// Input:
// func(8);
// Output:
// 'Понедельник'
const newObj29 = {
  1: 'Понедельник',
  2: 'Вторник',
  3: 'Среда',
  4: 'Четверг',
  5: 'Пятница',
  6: 'Суббота',
  7: 'Воскресенье'
};
const getWeekDay29 = (obj, day) => {

  let newDay = '';
  if (day <= 7) {
    for (const key in obj) {
      if (day == key) {
        newDay = obj[key];
        console.log("taskJS_29/34-", newDay);
      }
    }
  } if ((day > 7) && (day <= 14)) {
    day = day - 7;
    for (const key in obj) {
      if (day == key) {
        newDay = obj[key];
        console.log("taskJS_29/34-", newDay);
      }
    }
  }
  if ((day > 14) && (day <= 21)) {
    day = day - 14;
    for (const key in obj) {
      if (day == key) {
        newDay = obj[key];
        console.log("taskJS_29/34-", newDay);
      }
    }
  } if ((day > 21) && (day <= 28)) {
    day = day - 21;
    for (const key in obj) {
      if (day == key) {
        newDay = obj[key];
        console.log("taskJS_29/34-", newDay);
      }
    }
  } if (day > 28) {
    day = day - 28;
    for (const key in obj) {
      if (day == key) {
        newDay = obj[key];
        console.log("taskJS_29/34-", newDay);
      }
    }
  }

}


const result29 = getWeekDay29(newObj29, 19);



// 30/34
// Вернуть массив значений объекта
// Input:
// {
//   name: 'test',
//   age: 34,
//   country: 'RF'
// }
// Output:
// ['test', 34, 'RF']

const obj30 = {
  name: 'test',
  age: 34,
  country: 'RF'
};

let arr30 = [];

const testFunction30 = (obj) => {
  for (let key in obj) {
    arr30.push(obj[key]);
  }
  return console.log("taskJS_30/34-", arr30);
}
const result30 = testFunction30(obj30);

// 31/34
// Реализуйте функцию. 
// На вход функция принимает массив значений из 0 и 1. 
// Верните объект сгруппированных данных {'0': 10, '1': 5}
// Input:
// [0, 0, 0, 1, 1, 0 , 1, 1, 1, 0, 0, 1, 1, 0, 1]
// Output:
// {
//   '0': 7,
//   '1': 8
// }
const arr31 = [0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1];

let newObj31 = {
  0: 0,
  1: 0,
};

let countOneItem = 0;
let countZeroItem = 0;

const testFunction31 = (arr) => {

  arr.forEach(value => {
    if (value === 0) {
      ++countZeroItem;
    } else {
      ++countOneItem;
    }
  });

  addItem(newObj31);

  // console.log("taskJS_31/34-единицы", countOneItem);
  // console.log("taskJS_31/34-нули", countZeroItem);
}

const addItem = (obj) => {

  for (let key in obj) {
    if (key === '1') {
      obj[key] = countOneItem;
    } else {
      obj[key] = countZeroItem;
    }
  }
  console.log("taskJS_31/34", newObj31);
}

const result31 = testFunction31(arr31);


// 32/34
// Напишите функцию, которая преобразует массив вида 
// let arr = [
// {name: 'width', value: 300}, 
// {name: 'height', value: 100}
// ]; 
// в объект let obj = {width:300, height: 100}; 
// Количество объектов в массиве неограниченно.
// Input:
// [
//   {name: 'width', value: 300},
//   {name: 'height', value: 100}

// ];
// Output:
// {width: 300, height: 100}

let arr32 = [
  {
    name: 'width',
    value: 300
  },
  {
    name: 'height',
    value: 100
  }
];

const testFunction32 = (arr) => {
  let newObj32 = {};

  arr.forEach(obj => {
    newObj32[obj.name] = obj.value;
  });

  console.log("taskJS_32/34", newObj32)
}

const result32 = testFunction32(arr32);

//32/34



//34/34
// <input type="number">