// Написать функцию, которая параметром принимает массив элементов. 
// Функция возвращает true, если все элементы нечетные, иначе false.

const newArr = [1, 1, 1, 1, 1]

const testFunction1 = (arr) => {
  let flag = '';

  for (let i = 0; i < newArr.length; i++) {
    if (arr[i] % 2 !== 0) {
      flag = true;
      //console.log(flag);
      //return;
    } else {
      flag = false;
      console.log(flag);
      return;
    }
  }
  console.log(flag);
}

  const result = testFunction1(newArr);