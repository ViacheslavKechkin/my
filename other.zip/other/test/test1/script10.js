//С помощью метода map реализовать получение количества элементов в массиве

const array1 = [5, 8, 7, 3, 7, 3, 8,];

const testFunction10 = (arr) => {
  let count = 0;

  array1.map((el, index) => {
    count += 1;
  });

  console.log(count);
}

const result13 = testFunction10(array1);