const express = require('express');
const cors = require('cors');
const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

const { Schema } = mongoose;

const taskScheme = new Schema({
  text: String,
  text: String
});

const Task = mongoose.model("tasks", taskScheme);

//Создать роут для изменения данных о пользователе в БД.
app.patch('/updateUser', (req, res) => {
  const { body } = req;
  const { _id } = body;
  if (body.hasOwnProperty('_id') && (body.hasOwnProperty('text') || body.hasOwnProperty('isCheck'))) {
    Task.updateOne({ _id: _id }, body).then(() => {
      Task.find().then(result => {
        res.send({ data: result });
      });
    });
  }
};

app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});