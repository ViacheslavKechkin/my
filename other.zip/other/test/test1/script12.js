// Написать функцию, которая параметром принимает массив элементов. 
// Функция возвращает true, если хотя бы 1 элемент нечетный, иначе false. 
// И вернуть массив нечетных значений.


const array3 = [3, 5, 6, 8, 6, 3];

const testFunction12 = (arr) => {
  const result = [];
  let flag = false;

  arr.forEach(value => {
    if (value % 2 !== 0) {
      flag = true;
      result.push(value);
    }
  });

  return console.log(flag, result);
}

const result4 = testFunction12(array3); 