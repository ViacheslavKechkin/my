//импортирую фреймворки (который до этого установил npm install ...)
const express = require('express');
const cors = require('cors');
// для работы с базой данных подключаю mongoose
const mongoose = require("mongoose");
//инициализую express
const app = express();
const PORT = 8000;
//экспорт роутов 
const apiRoutes = require("./src/modules/routes/routes");
// app.use(express.json());
app.use(cors());
app.use(express.json());
//адрес подключения к базе данных
const uri = "mongodb+srv://vykechkin:kechkin123@cluster0.w2ver.mongodb.net/toDoListDB?retryWrites=true&w=majority";
//соединения с базой данных через mongoose
mongoose.connect(uri);
//запуск роута
app.use("/", apiRoutes);
//ставлю прослушивание порта
app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});