// Написать функцию, которая параметрами принимает: 
// массив объектов, название ключа. 
// Функция возвращает элемент со свойством, 
// которого значение максимальное.

let collectionArr = [
  {
    name: 'name1',
    age: 9
  },
  {
    name: 'name2',
    age: 39
  },
  {
    name: 'name3',
    age: 99
  },
];

const testFunction8 = (collection, val) => {
  let maxEl = -1;
  let countEl = -1;

  collection.forEach((item, index) => {
    if (item.age > maxEl) {
      maxEl = item.age;
      countEl = index;
    }
  });
  return console.log(collection[countEl]);
}

const result13 = testFunction8(collectionArr, 'age');