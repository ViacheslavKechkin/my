const express = require('express');
const cors = require('cors');
const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

const { Schema } = mongoose;

const taskScheme = new Schema({
  text: String,
  text: String
});

const Task = mongoose.model("tasks", taskScheme);

// Создать роут, который получит количество нужных значений и вернет 
// массив рандомных числовых значений в любом диапазоне. 
// Например, count: 3 => result: [9, 546, 73]
app.get('/random', (req, res) => {
  const newArr = [];
  const newFunction = () => {
    for (let i = 0; i < req.query.count; i++) {
      newArr.push(Math.floor(Math.random() * 1001));
    }
    res.send(newArr);
  }
  newFunction();
});
// Создать роут, который получит fullName пользователя 
// и вернет только его инициалы, например: 
// fullName: Denis Petrov => result: DP
app.get('/fullName', (req, res) => {
  let newName = '';
  let initialsName = req.query.fullName;
  const initials = () => {
    newName = initialsName.split(' ').map(w => w.substring(0, 1)).join('');
    res.send(newName);
  }
  initials();
});
//Создать роут на удаление пользователя из БД.
app.delete('/deleteUser', (req, res) => {
  const { id } = req.query;
  if (id) {
    Task.deleteUser({ _id: id }).then(() => {
      Task.find().then(result => {
        res.send({ data: result })
      });
    });
  }
  deleteUser();
});
//Создать роут для сохранения пользователя в БД.
app.post('/createUser', (req, res) => {
  const { body } = req;
  if (body) {
    task.save().then(() => {
      Task.find().then(result => {
        res.send({ data: result });
      });
    });
  }
});
//Создать роут для изменения данных о пользователе в БД.
app.patch('/updateUser', (req, res) => {
  const { body } = req;
  const { _id } = body;
  if (body.hasOwnProperty('_id') && (body.hasOwnProperty('text') || body.hasOwnProperty('isCheck'))) {
    Task.updateOne({ _id: _id }, body).then(() => {
      Task.find().then(result => {
        res.send({ data: result });
      });
    });
  }
};



app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});