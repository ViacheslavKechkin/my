const express = require('express');
const cors = require('cors');
const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

const { Schema } = mongoose;

const taskScheme = new Schema({
  text: String,
  text: String
});

const Task = mongoose.model("tasks", taskScheme);

//Создать роут для сохранения пользователя в БД.
app.post('/createUser', (req, res) => {
  console.log('task', task);
  const { body } = req;
  if (body) {
    task.save().then(() => {
      Task.find().then(result => {
        res.send({ data: result });
      });
    });
  }
});


app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});