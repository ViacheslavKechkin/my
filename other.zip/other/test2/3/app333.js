const express = require('express');
const cors = require('cors');
const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

//Создать роут на удаление пользователя из БД.
app.delete('/deleteUser', (req, res) => {
  const { id } = req.query;
  if (id) {
    Task.deleteUser({ _id: id }).then(() => {
      Task.find().then(result => {
        res.send({ data: result })
      });
    });
  } 
  deleteUser();
});




app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});