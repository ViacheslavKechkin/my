//3.1 Вернуть количество элементов в массиве

const elements = [4, 6, 2, 7, 8, 4];

const calcLength = (arrFunction) => {
  let length = 0;

  arrFunction.map(element => { // также можно через forEach
    length++;
  });

  return length;
}

const result = calcLength(elements);
console.log("task3.1-", result); // Выводит 6


// 3.2 Вывод всех элементов 
// соответствующих значению/условию в массиве

const array = [4, 6, 2, 7, 8, 4];

const testFunction = (arr, val) => {
  let newArray = [];

  arr.forEach((value, index) => {
    if (value > val) {
      newArray.push(value)
    }
  });

  return newArray;
}

const result2 = testFunction(array, 5);
console.log("task3.2-", result2); // Выводит [6, 7, 8]


// 3.3 Вывести количество элементов соответствующих условию
//Описание:
//В функцию передаем массив и значение. 
// По результату выполнения вывести количество элементов массива, 
// которые больше второго параметра.
const array2 = [4, 6, 2, 7, 8, 4];

const testFunction2 = (arr, val) => {
  let newArray = [];

  arr.forEach((value) => {
    if (value > val) {
      newArray.push(value)
    }
  });

  return lengthFunction(newArray);
}

const lengthFunction = (arr) => {
  let count = 0;

  arr.forEach((value, index) => {
    count = index + 1;
  });
  return count;
}


const result3 = testFunction2(array2, 5);
console.log("task3.3-", result3); // Выводит 3

// 3.4 Вывести индекс элемента в массиве
// Описание:
// В функцию передаем массив и значение. 
// По результату выполнения вывести все индексы элементов массива, 
// которые меньше второго параметра.

const array3 = [4, 6, 2, 7, 8, 4];

const testFunction3 = (arr, val) => {
  let newArray = [];

  arr.forEach((value, index) => {
    if (value < val) {
      newArray.push(index);
    }
  });

  return (newArray);
}

const lengthFunction1 = (arr) => {
  let count = 0;

  arr.forEach((value, index) => {
    count = index + 1;
  });

  return count;
}


const result4 = testFunction3(array3, 5);
console.log("task3.4-", result4); // Выводит индексы [0, 2, 5]

// 3.5 Найти индекс последнего элемента в массиве, 
// который соответсвует значению
// Описание:
// В функцию передаем массив и значение. 
// По результату выполнения вывести индекс последнего элемента массива, 
// который равен второму параметру.
// Пример:
// на вход функции ([4, 2, 7, 4, 2, 8], 2)
// Результат: 4
const array4 = [4, 6, 2, 7, 8, 4];

const testFunction4 = (arr, value) => {
  let number = -1;
  arr.forEach((element, index) => {
    if (element === value) {
      number = index;
    }
  });

  return number;
}

const result5 = testFunction4(array4, 4);
console.log("task3.5-", result5); // Выводит индекс [5]

// 3.6 Вывод всех объектов соответствующих 
// значению/условию в массиве объектов
// Описание:
// В функцию передаем коллекцию и значение. 
// По результату выполнения вывести все объекты массива, 
// конкретное свойство ('name', 'age' и тд), 
// которых равно второму параметру

let collectionArr = [
  {
    name: 'name1',
    age: 9
  },
  {
    name: 'name2',
    age: 89
  },
  {
    name: 'name3',
    age: 23
  },
  {
    name: 'name4',
    age: 34
  },
];

const testFunction5 = (arr, val) => {
  collectionArr.forEach(item => {
    if (item.name === val) {
      console.log("task3.6-", item)
    }
  });
}

const result6 = testFunction5(collectionArr, 'name3');

// 3.7 Вывод всех элементов, 
// где совпадает хотя бы одно значение из массива
// Описание:
// В функцию передаем массив и 2 значения. 
// По результату выполнения вывести все элементы массива, 
// которые равны или второму, или третьему параметру.

const array5 = [4, 24, 34, 2, 7, 8, 4, 34, 100, 222, 345];

const testFunction6 = (arr, val1, val2) => {
  arr.forEach(value => {
    if (value < val1 && value > val2) {
      console.log("task3.7-", value);
    }
  });
}

const result7 = testFunction6(array5, 50, 1);

// 3.8 Вывод всех объектов, где совпадает сразу 
// несколько полей значений из массива объектов
// Описание:
// В функцию передаем коллекцию и 2 значения. 
// По результату выполнения вывести все объекты массива, 
// у которых одно свойство ('name' )равно первому параметру 
// или другое свойство ('age') равно второму параметру.

let collectionArr2 = [
  {
    name: 'name1',
    age: 9
  },
  {
    name: 'name2',
    age: 89
  },
  {
    name: 'name1',
    age: 99
  },
  {
    name: 'name4',
    age: 34
  },
];

const testFunction7 = (arr, val1, val2) => {
  const result = [];
  arr.forEach(value => {
    if (value.name === val1 || value.age > val2) {
      result.push(value);
    }
  });

  return console.log("task3.8-", result);
}

const result8 = testFunction7(collectionArr2, 'name2', 18);

// 3.9 Вернуть все элементы, 
// которые противоположны предоставленному условию
// Описание:
// В функцию передаем массив и значение. 
// По результату выполнения вывести все элементы массива, 
// которые не равны второму параметру.

const testFunction8 = (arr, val1, val2) => {
  const result = [];
  arr.forEach(value => {
    if (!(value.name === val1 || value.age > val2)) {
      result.push(value);
    }
  });

  return console.log("task3.9-", result);
}

const result9 = testFunction8(collectionArr2, 'name2', 18);

// 3.10 Вернуть true, если все элементы соответствуют условию
// Описание:
// В функцию передаем коллекцию и 2 значения. 
// По результату выполнения вывести true, 
// если у всех объектов одно свойство равно второму параметру, 
// а другое свойство равно третьему параметру.

const testFunction9 = (arr, val1, val2) => {

  let result = false;

  arr.forEach(value => {
    if (value.name === val1 && value.age === val2) {
      result = true;
    } else {
      result = false;
      return result;
    }

    return console.log("task3.10-", result);
  });
}

const result10 = testFunction9(collectionArr2, 'name1', 9);

// 3.11 Вернуть true, если хотя бы один элемент 
// соответствует условию
// Описание:
// В функцию передаем коллекцию и 2 значения. 
// По результату выполнения вывести true, 
// если хотя бы у одного одно свойство равно второму параметру, 
// а другое свойство равно третьему параметру.

const testFunction10 = (arr, val1, val2) => {
  let result = false;

  let countAll = lengthFunction2(arr);
  let count = 0;

  arr.forEach(value => {
    if (value.name === val1 && value.age === val2) {
      result = true;
      return console.log("task3.11-", result);
    }
  });
}

const lengthFunction2 = (arr) => {
  let count = 0;

  arr.forEach((value, index) => {
    count = index - 1;
  });
}

const result11 = testFunction10(collectionArr2, 'name1', 9);

// 3.12 Вернуть true, 
// если в массиве или массиве объектов есть значение
// Описание:
// В функцию передаем массив и значение. 
// По результату выполнения вывести true, 
// если в массиве есть значение равное второму параметру.

const testFunction11 = (arr, val1) => {
  let result = false;

  arr.forEach(value => {
    if (value.name === val1) {
      result = true;
      return console.log("task3.12-", result);
    }
  });
}

const result12 = testFunction11(collectionArr2, 'name1');

// 3.13 Вернуть массив значений соответствующих 
// ключу из массива объектов
// Описание:
// В функцию передаем коллекцию и название ключа. 
// По результату выполнения вывести массив значений 
// по этому ключу всех объектов.

const testFunction12 = (arr, val) => {
  const valueArray = [];

  arr.forEach(item => {
    valueArray.push(item[val])
  });
  return console.log("task3.13-", valueArray);
}

const result13 = testFunction12(collectionArr2, 'name');

// 3.14 Найти максимальный/минимальный элемент 
// в массиве и массиве объектов
const array6 = [4, 24, 34, 2, 7, 8, 4, 34, 100, 222, 345];

let collectionArr3 = [
  {
    name: 'name1',
    age: 9
  },
  {
    name: 'name2',
    age: 89
  },
  {
    name: 'name1',
    age: 99
  },
  {
    name: 'name4',
    age: 34
  },
];

//для массива
//(для минимальных значений меняем знак на - и переменную)
const testFunction13 = (arr, val) => {
  let max = -1;

  arr.forEach(value => {
    if (value > max) {
      max = value;
    }
  });
  return console.log("task3.14(for array)-", max);
}

const result14 = testFunction13(array6, 'name');

//для коллекции 
//(для минимальных значений меняем знак на - и переменную)
const testFunction14 = (arr, val) => {
  let max = arr[0];

  arr.forEach(value => {
    if (value.age > max.age) {
      max = value;
    }
  });
  return console.log("task3.14(for collection)-", max);
}

const result15 = testFunction14(collectionArr3, 'name');

// 3.15 В функцию подается несколько массивов. 
// Вернуть один массив со всеми элементами.

const newArr1 = [8, 4, 34, 100, 222, 345];
const newArr2 = [4, 24, 34, 2, 7,];

const testFunction15 = (arr1, arr2) => {
  const result = [];

  arr1.forEach(item => result.push(item))
  arr2.forEach(item => result.push(item))

  return console.log("task3.15(for 2 arrays)-", result);
}

const result16 = testFunction15(newArr1, newArr2);

//Для неизвестного колличества массивов
//(используем spred)
const testFunction16 = (...arrays) => {
  //определенное количество массивов можно соеденить spred
  //let result = [...arrays[0], ...arrays[1], ...arrays[2]];
  const result = [];

  arrays.forEach(array => {
    array.forEach(item => result.push(item))
  });

  return console.log("task3.15(for multiple arrays)-", result);
}

const result17 = testFunction16(newArr1, newArr2, array6);

// 3.16 В функцию подается название св-ва. 
// Если свойство присутствует в объекте вывести "Exist", 
// если отсутсвует вывести "No exist"

let r = {
  rest: 5,
  test: 3
};

const testFunction17 = (objectVal, keyVal) => {
  const keys = [];
  for (let key in objectVal) {
    keys.push(key);
  }

  let flag = false;
  keys.forEach(item => {
    if (item === keyVal) {
      flag = true;
    }

  });

  return console.log("task3.16-", flag ? 'exist' : 'no exist');
}

const result18 = testFunction17(r, 'test');

// 3.17 Копирование массива/объекта
// Описание:
// В функцию передаем массив. 
// Нужно скопировать значения с одного массива в другой. 
// В скопированном массиве изменить любой элемент и вывести 2 массива.

const newArray1 = [8, 4, 34, 100, 222, 345];
//const newArray2 = [4, 24, 34, 2, 7,];

const testFunction18 = (arrayVal) => {
  // правильнее копировать через spred !!!
  let arrayCopy = [...arrayVal];
  //возможно еще таким образом
  //let arrayCopy = []; 
  // arrayVal.forEach(item => arrayCopy.push(item))

  arrayCopy[5] = 1024;
  console.log('task3.17- arrayCopy', arrayCopy);
  console.log('task3.17- arrayVal', arrayVal);
};

//return console.log("task3.17-");

const result19 = testFunction18(newArray1);

// 3.18 Напишите функцию filterFalse(arr), 
// которая очищает массив от ложных (false) значений
// Описание:
// В функцию передаем массив. Нужно вернуть массив, 
// в котором отсутствуют ложные значения:
// false, null, undefined, 0, –0, NaN и "" (пустая строка)

const arrFalse = [8, 4, null, -1, undefined, 34, 222, null, 345];

const filterFalse = (arr) => {
  const result = [];

  arr.forEach(item => {
    if (item && item > 0) {
      result.push(item);
    }
  });

  return console.log('task3.18-', result);
}

const result20 = filterFalse(arrFalse);

// 3.19 Напишите функцию moveElement(arr,from,to), 
// которая позволяет поменять местами элементы 
// из позиции from в позицию to.
const arrEl = [8, 4, 34, 222, 345];

const moveElement = (arr, from, to) => {
  const temp = arr[to];
  arr[to] = arr[from];
  arr[from] = temp;
  return console.log('task3.19-', arr);

}
const result21 = moveElement(arrEl, 1, 4);