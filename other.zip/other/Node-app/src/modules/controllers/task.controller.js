//делаю импорт модели
const Task = require('../../db/models/task/index');
//делаю экспорт функций
module.exports.getAllTasks = (req, res, next) => {
  //ожидает ответ от БД и получаю все таски 
  Task.find().then(result => {
    //отдаю полученые данные пользователю
    res.send({ data: result });
  });
};

module.exports.createNewTask = (req, res, next) => {
  // создаю таску на основе схемы Task
  const task = new Task(req.body);
  // save-сохраняю задачу на сервере, then - ожидаю результат
  task.save().then(result => {
    //отдаю полученые данные пользователю
    res.send(result);
  }).catch(err => console.log(err));
};

module.exports.changeTaskInfo = (req, res, next) => {
  Task.updateOne({ _id: req.body._id }, req.body).then(result => {
    Task.find({ _id: req.body._id }).then(result => {
      res.send(result);
    });
  });
};

module.exports.deleteTask = (req, res, next) => {
  Task.deleteOne({ _id: req.body._id }).then(result => {
    res.send('Success delete rask');
  });
};