// Написать функцию, которая параметрами принимает: массив элементов, 
// 1-е значение, 2-е значение. Вернуть массив индексов элементов, 
// значения которых совпадают с параметрами.

const array3 = [3, 5, 6, 7, 6, 3];

const testFunction3 = (arr, val, val2) => {
  let newArray = [];

  arr.forEach((value, index) => {
    if (value === val || value === val2) {
      newArray.push(index);
    }
  });

  return (newArray);
}

const result3 = testFunction3(array3, 5, 3);
console.log(result3); 