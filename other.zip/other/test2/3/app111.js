// Создать роут, который получит количество нужных значений и вернет 
// массив рандомных числовых значений в любом диапазоне. 
// Например, count: 3 => result: [9, 546, 73]
const express = require('express');
const cors = require('cors');

const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

app.get('/random', (req, res) => {
  const newArr = [];
  const newFunction = () => {
    for (let i = 0; i < req.query.count; i++) {
      newArr.push(Math.floor(Math.random() * 1001));
    }
    res.send(newArr);
  }
  newFunction();
});

app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});
