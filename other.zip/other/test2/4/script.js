let valueInput = '';

input = document.getElementById('input-id');
console.log(input);
input.addEventListener('change', updateValue);
const updateValue = (event) => valueInput = event.target.value;
console.log(valueInput);