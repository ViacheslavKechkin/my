
//console.log(Math.floor(Math.random() * 101));
const express = require('express');
const cors = require('cors');

const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

const { Schema } = mongoose;

const taskScheme = new Schema({
  text: String,
  isCheck: Boolean
});

const Task = mongoose.model("tasks", taskScheme);

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  console.log('a', a);
  res.send('Hello');
  // res.send('a', a);
  // Task.find().then(result => {
  //   console.log(result);
  //   res.send({ data: result });
  // });
});


app.get('/random', (req, res) => {
  //получаю объект который передал по адресу
  console.log('req', req.query);
  console.log('req', req.query.count);
  //вернуть обратно
  // res.send(req.query);
  const newArr = [];
  
  const newFunction = () => {
    for (let i = 0; i < req.query.count; i++) {
      newArr.push(Math.floor(Math.random() * 101));
    }
    res.send(newArr);
  }
  console.log('newArr', newArr);
  newFunction();
});



app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});
