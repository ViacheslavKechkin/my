const express = require('express');
const router = express.Router();
//делаю импорт функций - контроллеров
const {
  getAllTasks,
  createNewTask,
  changeTaskInfo,
  deleteTask
} = require('../controllers/task.controller');

//Tasks routes
router.get('/allTasks', getAllTasks);
router.post('/createNewTask', createNewTask);
router.patch('/updateTask', changeTaskInfo);
router.delete('/deleteTask', deleteTask);

module.exports = router;