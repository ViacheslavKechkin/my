// Написать функцию, которая параметром принимает массив. 
// Функция возвращает true, если хотя бы 1 значение положительное, иначе false. 
// И вернуть массив положительных значений.


const array = [-4, 6, -2, ];

const testFunction15 = (arr) => {
  let result = false;

  arr.forEach(value => {
    if (value >= 0) {
      result = true;
    } 
  });
  return console.log(result);
}

const result12 = testFunction15(array);