// Написать функцию, которая параметрами принимает: массив объектов, 
// ключ, значение. Функция возвращает массив объектов, 
// у которых по заданному ключу совпадает заданное значение. 
// Но в массиве хранятся объекты у которых может отсутствовать 
// данное свойство или быть вообще пустым объектом.

let collectionArr = [
  {
    name: 'name1',
    age: 9
  },
  {
    name: 'name2',
    age: 33
  },
  {
    name: 'name3',
    age: 23
  },
  {
    name: 'name4',
    age: ''
  }
];

const testFunction4 = (arr, val1, val2) => {
  const result = [];

  arr.forEach(value => {
    if (value.age === val2) {
      result.push(value);
    }
  });

  return console.log(result);
}

const result4 = testFunction4(collectionArr, 'age', 33); 