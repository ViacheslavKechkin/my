// Написать функцию, которая параметрами принимает: массив элементов, 
// 1-е значение, 2-е значение. Вернуть массив значений, 
// которые больше эти 2-х параметров.

const newArr = [1, 4, 1, 3, 10, 6]

const testFunction2 = (arr, el1, el2) => {
  let newArr = [];

  arr.forEach(arrItem => {
    if (arrItem > el1 && arrItem > el2) {
      newArr.push(arrItem)
    }
  });

  console.log(newArr);
}

const result = testFunction2(newArr, 1, 5);