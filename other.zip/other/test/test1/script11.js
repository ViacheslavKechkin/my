// Написать функцию, которая параметром принимает массив элементов. 
// Отобрать массив с нечетными элементами. 
// Вернуть массив со значениями, которые отсутствуют в получившемся массиве.


const array3 = [3, 5, 6, 8, 6, 3];

const testFunction5 = (arr) => {
  const result = [];
  const result2 = [];

  arr.forEach(value => {
    if (value % 2 !== 0) {
      result.push(value);
    } else {
      result2.push(value);
    }
  });

  return console.log(result2);
  
}

const result4 = testFunction5(array3); 