// Написать функцию, которая параметрами принимает: несколько массивов. 
// Функция возвращает один массив со всеми элементами этих массивов, 
// исключая повторения.


// СДЕЛТЬ НЕ ПОЛУЧИЛОСЬ


const newArr1 = [8, 4, 34, 100, 222, 333];
const newArr2 = [4, 1111, 999, 888, 222,];

const testFunction15 = (arr1, arr2) => {

  let flag = false;
  let newArr = [...newArr1, ...newArr2];
  let arr = [];

  arr2.forEach(el2 => {
    newArr.forEach(elNewArr => {
      if (el2 === elNewArr) {
        flag = false;
        return;
      } else {
        flag = true;
      }
    });

    if (flag) {
      arr.push(el2);
    }
  });
  console.log(arr);
  // arr2.forEach(itemArr2 => {

  //   arr1.forEach(itemArr1 => {
  //     if (itemArr2 === itemArr1) {
  //       flag = false;

  //     } if (flag === true) {
  //       result.push(itemArr2);
  //     }
  //   });


  // else {
  //   return flag = true;
  //   //return result.push(itemArr2);
  // }
  // });

  // return console.log(result);
}

const result16 = testFunction15(newArr1, newArr2);