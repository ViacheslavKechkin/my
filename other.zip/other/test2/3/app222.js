// Создать роут, который получит fullName пользователя 
// и вернет только его инициалы, например: 
// fullName: Denis Petrov => result: DP
const express = require('express');
const cors = require('cors');

const mongoose = require("mongoose");
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());

app.get('/fullName', (req, res) => {
  let newName = '';
  let initialsName = req.query.fullName;
  const initials = () => {
    newName = initialsName.split(' ').map(w => w.substring(0, 1)).join('');
    res.send(newName);
  }
  initials();
});






app.listen(PORT, () => {
  console.log(`Example app lestening on port ${PORT}!`)
});